#!/bin/bash
# iperf_test.sh
# Usage:
#   chmod a+x iperf_test.sh
#   ./iperf_test.sh [-b nic|router] [-t <packet_size>] [-l <test_duration>] [-i <interval>] [-w <bandwidth>]

usage() {
    echo "Usage: $0 [-b nic|router] [-t <packet_size>] [-l <test_duration>] [-i <interval>] [-w <bandwidth>]"
    echo "Options:"
    echo "  -b    : Bitfile type (nic or router), default: nic"
    echo "  -t    : UDP packet size in bytes, default: 512"
    echo "  -l    : Test duration in seconds, default: 30"
    echo "  -i    : Test interval in seconds, default: 2"
    echo "  -w    : Target bandwidth (e.g., 250M, 500M, 1G), default: 1G"
    exit 1
}

# ============================================================================
# HARDCODED CREDENTIALS
# ============================================================================
TEAM_NUM=2
PASSWORD="BvGgYXcze3mb"

# Defaults
BITFILE_TYPE="nic"
PACKET_SIZE=512
TEST_DURATION=30
INTERVAL=2
BANDWIDTH="1G"
RKD_ENABLE=0

# Parse parameters
while getopts "b:t:l:i:w:r" opt; do
    case $opt in
        b) BITFILE_TYPE="$OPTARG" ;;
        t) PACKET_SIZE="$OPTARG" ;;
        l) TEST_DURATION="$OPTARG" ;;
        i) INTERVAL="$OPTARG" ;;
        w) BANDWIDTH="$OPTARG" ;;
        r) RKD_ENABLE=1 ;;
        *) usage ;;
    esac
done

# Output file
OUTPUT_FILE="iperf_test_udp_team${TEAM_NUM}_${BITFILE_TYPE}_sz${PACKET_SIZE}_t${TEST_DURATION}_i${INTERVAL}.md"

# Compute node numbers
ND=$((TEAM_NUM % 5))
CL=$(((TEAM_NUM / 5) * 5))
M0=$((ND + CL))  # netfpga node
M1=$((((ND + 1) % 5) + CL))
M2=$((((ND + 2) % 5) + CL))
M3=$((((ND + 3) % 5) + CL))
M4=$((((ND + 4) % 5) + CL))

NODES=($M1 $M2 $M3 $M4)

NODE_PORTS[$M1]=5001
NODE_PORTS[$M2]=5002
NODE_PORTS[$M3]=5003
NODE_PORTS[$M4]=5004

if [ "$BITFILE_TYPE" != "nic" ] && [ "$BITFILE_TYPE" != "router" ]; then
    echo "Invalid bitfile type: $BITFILE_TYPE. Must be 'nic' or 'router'."
    usage
fi

if [ "$BITFILE_TYPE" = "router" ]; then
    RKD_ENABLE=1
    echo "Router bitfile selected. RKD will be enabled."
fi

# ============================================================================
# COMPUTE DATA PLANE IPs
# ============================================================================
SUBNET_BASE=$((ND * 4))
HOST_ID=$((ND + 1))

NODE_IP[$M1]="10.0.$((SUBNET_BASE + 0)).$HOST_ID"   # Port 0
NODE_IP[$M2]="10.0.$((SUBNET_BASE + 1)).$HOST_ID"   # Port 1
NODE_IP[$M3]="10.0.$((SUBNET_BASE + 2)).$HOST_ID"   # Port 2
NODE_IP[$M4]="10.0.$((SUBNET_BASE + 3)).$HOST_ID"   # Port 3

NODE_ADDR[$M1]="${NODE_IP[$M1]}"
NODE_ADDR[$M2]="${NODE_IP[$M2]}"
NODE_ADDR[$M3]="${NODE_IP[$M3]}"
NODE_ADDR[$M4]="${NODE_IP[$M4]}"

NODE_SSH[$M0]="nf$M0.usc.edu"
NODE_SSH[$M1]="nf$M1.usc.edu"
NODE_SSH[$M2]="nf$M2.usc.edu"
NODE_SSH[$M3]="nf$M3.usc.edu"
NODE_SSH[$M4]="nf$M4.usc.edu"

echo ""
echo "============================================"
echo "  NetFPGA iperf UDP Test Script"
echo "============================================"
echo ""
echo "Team:            $TEAM_NUM"
echo "Bitfile:         $BITFILE_TYPE"
echo "Packet Size:     $PACKET_SIZE bytes"
echo "Duration:        $TEST_DURATION sec"
echo "Target BW:       $BANDWIDTH"
echo ""
echo "Node Mapping:"
echo "  NetFPGA (nf$M0)  — FPGA router/NIC"
echo "  nf$M1 (Port 0) — SSH: ${NODE_SSH[$M1]} | Data: ${NODE_ADDR[$M1]}:${NODE_PORTS[$M1]}"
echo "  nf$M2 (Port 1) — SSH: ${NODE_SSH[$M2]} | Data: ${NODE_ADDR[$M2]}:${NODE_PORTS[$M2]}"
echo "  nf$M3 (Port 2) — SSH: ${NODE_SSH[$M3]} | Data: ${NODE_ADDR[$M3]}:${NODE_PORTS[$M3]}"
echo "  nf$M4 (Port 3) — SSH: ${NODE_SSH[$M4]} | Data: ${NODE_ADDR[$M4]}:${NODE_PORTS[$M4]}"
echo ""
echo "Control plane: SSH via hostnames (management network)"
echo "Data plane:    iperf/ping via direct IPs (through NetFPGA)"
echo ""

# Create test results file
{
  echo "# Network Bandwidth Test Results (UDP)"
  echo ""
  echo "## Test Information"
  echo "* Date: $(date)"
  echo "* Team Number: $TEAM_NUM"
  echo "* Bitfile Type: $BITFILE_TYPE"
  echo "* Protocol: UDP"
  echo "* Packet Size: $PACKET_SIZE bytes"
  echo "* Test Duration: $TEST_DURATION seconds"
  echo "* Test Interval: $INTERVAL seconds"
  echo "* Target Bandwidth: $BANDWIDTH"
  echo "* RKD Enabled: $([ $RKD_ENABLE -eq 1 ] && echo "Yes" || echo "No")"
  echo ""
  echo "### Node Mapping"
  echo "* NetFPGA Router: nf$M0"
  echo "* Control plane: SSH via hostnames (management network)"
  echo "* Data plane: iperf/ping via direct IPs (through NetFPGA)"
  echo "* Node Ports:"
  echo "  - nf$M1 (Port 0): SSH=${NODE_SSH[$M1]} | Data=${NODE_ADDR[$M1]}:${NODE_PORTS[$M1]}"
  echo "  - nf$M2 (Port 1): SSH=${NODE_SSH[$M2]} | Data=${NODE_ADDR[$M2]}:${NODE_PORTS[$M2]}"
  echo "  - nf$M3 (Port 2): SSH=${NODE_SSH[$M3]} | Data=${NODE_ADDR[$M3]}:${NODE_PORTS[$M3]}"
  echo "  - nf$M4 (Port 3): SSH=${NODE_SSH[$M4]} | Data=${NODE_ADDR[$M4]}:${NODE_PORTS[$M4]}"
  echo ""
  echo "## Test Results"
} > "$OUTPUT_FILE"

# Set bitfile path based on type
if [ "$BITFILE_TYPE" = "router" ]; then
    BITFILE="/home/netfpga/bitfiles/reference_router.bit"
else
    BITFILE="/home/netfpga/bitfiles/reference_nic.bit"
fi

# Download bit file on FPGA node
echo "Downloading bitfile to nf$M0..."
sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no netfpga@${NODE_SSH[$M0]} "nf_download $BITFILE" 2>&1 | tee -a "$OUTPUT_FILE"

# Give FPGA more time to fully initialize after bitfile load
echo "Waiting 10s for FPGA to fully initialize..."
sleep 10

# ============================================================================
# START RKD (if router mode)
# ============================================================================
if [ $RKD_ENABLE -eq 1 ]; then
    echo ""
    echo "============================================"
    echo "  Starting RKD on nf$M0"
    echo "============================================"

    # Kill any existing RKD
    echo "Killing any existing RKD processes on nf$M0..."
    sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no netfpga@${NODE_SSH[$M0]} \
        "killall rkd 2>/dev/null; sleep 2"

    # Launch rkd exactly as the user would: "rkd &"
    # Use disown so it survives SSH disconnect; redirect output to log for debugging
    echo "Launching: rkd &"
    sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no netfpga@${NODE_SSH[$M0]} \
        "rkd > /tmp/rkd.log 2>&1 & disown; sleep 2; echo RKD_PID=\$!"

    echo "Waiting 20s for RKD to converge routing tables..."
    sleep 20

    # Verify RKD is running
    RKD_CHECK=$(sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no netfpga@${NODE_SSH[$M0]} \
        "ps aux | grep '[r]kd' | grep -v grep | wc -l" 2>/dev/null)
    RKD_CHECK=${RKD_CHECK:-0}

    if [ "$RKD_CHECK" -ge 1 ]; then
        echo "✓ RKD confirmed running on nf$M0"
    else
        echo "✗ RKD is NOT running on nf$M0 (attempt 1)."
        echo ""
        echo "=== RKD Log ==="
        sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no netfpga@${NODE_SSH[$M0]} \
            "cat /tmp/rkd.log 2>/dev/null"
        echo "================"
        echo ""

        # Retry: use -tt to force pseudo-terminal allocation (helps some environments)
        echo "Retrying with forced PTY allocation..."
        sshpass -p "$PASSWORD" ssh -tt -o StrictHostKeyChecking=no netfpga@${NODE_SSH[$M0]} \
            "killall rkd 2>/dev/null; sleep 1; rkd > /tmp/rkd.log 2>&1 & sleep 3; exit" 2>/dev/null

        echo "Waiting 20s for RKD convergence (retry)..."
        sleep 20

        RKD_CHECK=$(sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no netfpga@${NODE_SSH[$M0]} \
            "ps aux | grep '[r]kd' | grep -v grep | wc -l" 2>/dev/null)
        RKD_CHECK=${RKD_CHECK:-0}

        if [ "$RKD_CHECK" -ge 1 ]; then
            echo "✓ RKD confirmed running on retry"
        else
            echo "✗ RKD still not running after retry."
            echo ""
            echo "=== RKD Log (retry) ==="
            sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no netfpga@${NODE_SSH[$M0]} \
                "cat /tmp/rkd.log 2>/dev/null"
            echo "========================"
            echo ""
            echo "WARNING: Continuing without RKD. Cross-port routing will likely fail."
            echo ""
        fi
    fi

    # Show RKD log
    echo ""
    echo "=== RKD Log (last 20 lines) ==="
    sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no netfpga@${NODE_SSH[$M0]} \
        "cat /tmp/rkd.log 2>/dev/null | tail -20"
    echo ""

    # Show routing table
    echo "=== NetFPGA Routing Table ==="
    sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no netfpga@${NODE_SSH[$M0]} \
        "nf_show_routes 2>/dev/null || echo '(nf_show_routes not available)'"
    echo "=============================="
    echo ""

    # Log to output file
    {
      echo ""
      echo "### RKD Status"
      RKD_FINAL=$(sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no netfpga@${NODE_SSH[$M0]} \
          "ps aux | grep '[r]kd' | grep -v grep | wc -l" 2>/dev/null)
      if [ "${RKD_FINAL:-0}" -ge 1 ]; then
          echo "* RKD confirmed running on nf$M0"
      else
          echo "* **WARNING: RKD is NOT running on nf$M0**"
      fi
      echo ""
      echo "#### RKD Log (last 20 lines)"
      echo "\`\`\`"
    } >> "$OUTPUT_FILE"
    sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no netfpga@${NODE_SSH[$M0]} \
        "cat /tmp/rkd.log 2>/dev/null | tail -20" >> "$OUTPUT_FILE"
    {
      echo "\`\`\`"
      echo ""
    } >> "$OUTPUT_FILE"
fi

sleep 5

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

extract_bandwidth_udp() {
    local output="$1"
    local bw

    bw=$(echo "$output" | grep -A 1 "Server Report" | grep -oE '[0-9.]+ Mbits/sec' | grep -oE '[0-9.]+' | tail -1)

    if [ -z "$bw" ]; then
        bw=$(echo "$output" | grep -oE '[0-9.]+ Mbits/sec' | tail -1 | grep -oE '[0-9.]+')
    fi

    echo "$bw"
}

extract_packet_loss() {
    local output="$1"
    local loss

    loss=$(echo "$output" | sed -n 's/.*(\([0-9.]*\)%).*/\1/p' | tail -1)

    if [ -z "$loss" ]; then
        loss=$(echo "$output" | grep -oP '\(\K[0-9.]+(?=%\))' 2>/dev/null | tail -1)
    fi

    if [ -z "$loss" ]; then
        loss=$(echo "$output" | grep -Eo '\([0-9.]+%\)' | tail -1 | tr -d '()%')
    fi

    if [ -z "$loss" ]; then
        loss="N/A"
    fi

    echo "$loss"
}

extract_jitter() {
    local output="$1"
    local jitter

    jitter=$(echo "$output" | grep -A 1 "Server Report" | grep -oE '[0-9.]+ ms' | head -1 | grep -oE '[0-9.]+')

    if [ -z "$jitter" ]; then
        jitter="N/A"
    fi

    echo "$jitter"
}

TEMP_DIR=$(mktemp -d)
BW_FILE="$TEMP_DIR/bandwidth.txt"
AGG_BW_FILE="$TEMP_DIR/aggregate_bandwidth.txt"

> "$BW_FILE"
> "$AGG_BW_FILE"

run_iperf_client() {
    local server_node="$1"
    local client_node="$2"
    local output_file="$3"
    local bw_file="$4"
    local port="$5"

    local server_addr="${NODE_ADDR[$server_node]}"
    local client_ssh="${NODE_SSH[$client_node]}"

    {
      echo ""
      echo "### Test: nf$client_node → nf$server_node ($server_addr:$port)"
      echo ""
      echo "\`\`\`"
    } >> "$output_file"

    local PROTO_PARAMS="-u -l $PACKET_SIZE -b $BANDWIDTH"

    local result
    result=$(sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@$client_ssh \
        "iperf -c $server_addr $PROTO_PARAMS -i $INTERVAL -t $TEST_DURATION -p $port" 2>&1)

    echo ""
    echo "--- iperf result: nf$client_node → nf$server_node ($server_addr:$port) ---"
    echo "$result"

    echo "$result" >> "$output_file"

    local bw
    bw=$(extract_bandwidth_udp "$result")

    local loss
    loss=$(extract_packet_loss "$result")

    local jitter
    jitter=$(extract_jitter "$result")

    echo "$bw" >> "$bw_file"

    {
      echo "\`\`\`"
      echo "**Completed:** nf$client_node → nf$server_node ($server_addr:$port) | BW: ${bw} Mbits/sec | Loss: ${loss}% | Jitter: ${jitter} ms"
      echo ""
    } >> "$output_file"

    echo ">>> Completed: nf$client_node → nf$server_node ($server_addr:$port) | BW: ${bw} Mbits/sec | Loss: ${loss}% | Jitter: ${jitter} ms"
    echo ""
}

# ============================================================================
# PHASE 1: LATENCY & CROSS-PORT CONNECTIVITY VERIFICATION
# ============================================================================
{
  echo ""
  echo "---"
  echo ""
  echo "## Phase 1: Latency & Cross-Port Connectivity Verification"
  echo ""
  echo "Testing RTT latency and connectivity across all port pairs via data plane IPs."
  echo ""
  if [ "$BITFILE_TYPE" = "router" ]; then
      echo "Router mode: Adjacent AND cross-port pairs should succeed."
  else
      echo "NIC mode: Only adjacent port pairs should succeed. Cross-port expected to FAIL."
  fi
  echo ""
} >> "$OUTPUT_FILE"

echo "=== Phase 1: Latency & Cross-Port Connectivity Verification ==="

PING_COUNT=5
PING_TIMEOUT=5

LATENCY_RESULTS_FILE="$TEMP_DIR/latency_results.txt"
> "$LATENCY_RESULTS_FILE"

{
  echo "### Latency Matrix (RTT in ms)"
  echo ""
  printf "| %-16s | %-12s | %-20s | %-10s | %-8s | %-10s | %-10s | %-10s | %-8s |\n" \
         "Source" "Destination" "Target Address" "Pair Type" "Status" "Min RTT" "Avg RTT" "Max RTT" "Loss %"
  echo "|------------------|--------------|----------------------|------------|----------|------------|------------|------------|----------|"
} >> "$OUTPUT_FILE"

for src_node in "${NODES[@]}"; do
    for dst_node in "${NODES[@]}"; do
        [ "$src_node" = "$dst_node" ] && continue

        local_dst_addr="${NODE_ADDR[$dst_node]}"
        src_ssh="${NODE_SSH[$src_node]}"

        echo "Pinging $local_dst_addr (nf$dst_node) from nf$src_node ($PING_COUNT packets)..."

        ping_result=$(sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no \
            node$ND@$src_ssh \
            "ping -c $PING_COUNT -W $PING_TIMEOUT $local_dst_addr 2>&1")

        echo "  [DEBUG] $(echo "$ping_result" | tail -2)"

        loss=$(echo "$ping_result" | grep -oE '[0-9.]+% packet loss' | grep -oE '[0-9.]+' | head -1)
        [ -z "$loss" ] && loss="100"

        rtt_line=$(echo "$ping_result" | grep -oE '[0-9]+\.[0-9]+/[0-9]+\.[0-9]+/[0-9]+\.[0-9]+/[0-9]+\.[0-9]+' | tail -1)

        if [ -n "$rtt_line" ]; then
            rtt_min=$(echo "$rtt_line" | cut -d'/' -f1)
            rtt_avg=$(echo "$rtt_line" | cut -d'/' -f2)
            rtt_max=$(echo "$rtt_line" | cut -d'/' -f3)
            status="OK"
        else
            received=$(echo "$ping_result" | grep -oE '[0-9]+ received' | grep -oE '[0-9]+')
            if [ -n "$received" ] && [ "$received" -gt 0 ]; then
                rtt_avg=$(echo "$ping_result" | grep -oE 'avg[^0-9]*([0-9.]+)' | grep -oE '[0-9.]+' | tail -1)
                rtt_min="N/A"
                rtt_max="N/A"
                status="OK"
                [ -z "$rtt_avg" ] && rtt_avg="N/A"
            else
                rtt_min="N/A"
                rtt_avg="N/A"
                rtt_max="N/A"
                status="FAIL"
            fi
        fi

        pair_type=""
        if { [ "$src_node" = "$M1" ] && [ "$dst_node" = "$M2" ]; } || \
           { [ "$src_node" = "$M2" ] && [ "$dst_node" = "$M1" ]; } || \
           { [ "$src_node" = "$M3" ] && [ "$dst_node" = "$M4" ]; } || \
           { [ "$src_node" = "$M4" ] && [ "$dst_node" = "$M3" ]; }; then
            pair_type="adjacent"
        else
            pair_type="cross-port"
        fi

        echo "  nf$src_node → nf$dst_node [$pair_type] ($local_dst_addr): status=$status, avg_rtt=${rtt_avg}ms, loss=${loss}%"

        printf "| nf%-14s | nf%-10s | %-20s | %-10s | %-8s | %-10s | %-10s | %-10s | %-8s |\n" \
               "$src_node" "$dst_node" "$local_dst_addr" "$pair_type" "$status" \
               "${rtt_min}ms" "${rtt_avg}ms" "${rtt_max}ms" "${loss}%" >> "$OUTPUT_FILE"

        echo "$src_node $dst_node $pair_type $status $rtt_avg $loss" >> "$LATENCY_RESULTS_FILE"
    done
done

adjacent_ok=0
adjacent_fail=0
cross_ok=0
cross_fail=0

while read -r src dst ptype pstatus pavg ploss; do
    if [ "$ptype" = "adjacent" ]; then
        [ "$pstatus" = "OK" ] && adjacent_ok=$((adjacent_ok + 1)) || adjacent_fail=$((adjacent_fail + 1))
    else
        [ "$pstatus" = "OK" ] && cross_ok=$((cross_ok + 1)) || cross_fail=$((cross_fail + 1))
    fi
done < "$LATENCY_RESULTS_FILE"

adj_rtt_sum=0
adj_rtt_count=0
cross_rtt_sum=0
cross_rtt_count=0

while read -r src dst ptype pstatus pavg ploss; do
    if [ "$pstatus" = "OK" ] && [ "$pavg" != "N/A" ]; then
        if [ "$ptype" = "adjacent" ]; then
            adj_rtt_sum=$(echo "$adj_rtt_sum + $pavg" | bc)
            adj_rtt_count=$((adj_rtt_count + 1))
        else
            cross_rtt_sum=$(echo "$cross_rtt_sum + $pavg" | bc)
            cross_rtt_count=$((cross_rtt_count + 1))
        fi
    fi
done < "$LATENCY_RESULTS_FILE"

avg_adjacent_rtt="N/A"
avg_cross_rtt="N/A"
[ $adj_rtt_count -gt 0 ] && avg_adjacent_rtt=$(echo "scale=3; $adj_rtt_sum / $adj_rtt_count" | bc)
[ $cross_rtt_count -gt 0 ] && avg_cross_rtt=$(echo "scale=3; $cross_rtt_sum / $cross_rtt_count" | bc)

{
  echo ""
  echo "### Connectivity Summary"
  echo ""
  echo "* **Adjacent port pairs** (NIC + Router): $adjacent_ok passed, $adjacent_fail failed"
  echo "* **Cross port pairs** (Router only):     $cross_ok passed, $cross_fail failed"
  echo ""
  echo "### Latency Summary"
  echo ""
  echo "* Average RTT (adjacent pairs): ${avg_adjacent_rtt} ms"
  echo "* Average RTT (cross-port pairs): ${avg_cross_rtt} ms"
  echo ""
} >> "$OUTPUT_FILE"

echo ""
echo "--- Phase 1 Summary ---"
echo "Adjacent pairs:    $adjacent_ok OK, $adjacent_fail FAIL (avg RTT: ${avg_adjacent_rtt} ms)"
echo "Cross-port pairs:  $cross_ok OK, $cross_fail FAIL (avg RTT: ${avg_cross_rtt} ms)"

if [ "$BITFILE_TYPE" = "nic" ] && [ $cross_ok -gt 0 ]; then
    echo "WARNING: Cross-port pairs succeeded in NIC mode — unexpected!"
    echo "* **WARNING:** Cross-port pairs succeeded in NIC mode. Verify topology." >> "$OUTPUT_FILE"
elif [ "$BITFILE_TYPE" = "router" ] && [ $cross_fail -gt 0 ]; then
    echo "WARNING: Cross-port pairs failed in Router mode — check RKD and routing tables."
    echo "* **WARNING:** Cross-port pairs failed in Router mode. Check RKD/routing." >> "$OUTPUT_FILE"
fi

echo ""
sleep 5

# ============================================================================
# PHASE 2: AGGREGATE THROUGHPUT TEST (UNIDIRECTIONAL)
# ============================================================================
{
  echo ""
  echo "---"
  echo ""
  echo "## Phase 2: Aggregate Throughput Test (Unidirectional)"
  echo ""
  echo "Testing 2 simultaneous non-overlapping flows to measure aggregate capacity."
  echo "* Flow 1: nf$M1 → nf$M2 (${NODE_ADDR[$M1]} → ${NODE_ADDR[$M2]})"
  echo "* Flow 2: nf$M3 → nf$M4 (${NODE_ADDR[$M3]} → ${NODE_ADDR[$M4]})"
  echo ""
} >> "$OUTPUT_FILE"

echo "=== Phase 2: Aggregate Throughput Test (Unidirectional) ==="

TEMP_FILE_1="$TEMP_DIR/result_${M1}_to_${M2}_agg.txt"
TEMP_FILE_2="$TEMP_DIR/result_${M3}_to_${M4}_agg.txt"

echo "Cleaning up any leftover iperf processes..."
for node in "${NODES[@]}"; do
    sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$node]} \
        "killall iperf 2>/dev/null || true" &
done
wait
sleep 2

echo "Starting iperf servers on nf$M2 (port ${NODE_PORTS[$M2]}) and nf$M4 (port ${NODE_PORTS[$M4]})..."
SERVER_PID_M2=$(sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$M2]} \
    "nohup iperf -s -u -p ${NODE_PORTS[$M2]} > /dev/null 2>&1 & echo \$!")
SERVER_PID_M4=$(sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$M4]} \
    "nohup iperf -s -u -p ${NODE_PORTS[$M4]} > /dev/null 2>&1 & echo \$!")
sleep 3

echo "Verifying iperf servers..."
for check_node in $M2 $M4; do
    SRV_CHECK=$(sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$check_node]} \
        "ps aux | grep -c '[i]perf'")
    if [ "$SRV_CHECK" -ge 1 ]; then
        echo "  ✓ iperf server running on nf$check_node"
    else
        echo "  ✗ iperf server NOT running on nf$check_node — restarting..."
        sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$check_node]} \
            "nohup iperf -s -u -p ${NODE_PORTS[$check_node]} > /dev/null 2>&1 &"
        sleep 2
    fi
done

echo "Running simultaneous flows..."
run_iperf_client "$M2" "$M1" "$TEMP_FILE_1" "$AGG_BW_FILE" "${NODE_PORTS[$M2]}" &
PID1=$!
run_iperf_client "$M4" "$M3" "$TEMP_FILE_2" "$AGG_BW_FILE" "${NODE_PORTS[$M4]}" &
PID2=$!

wait $PID1 $PID2

sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$M2]} "kill $SERVER_PID_M2 >/dev/null 2>&1; killall iperf 2>/dev/null || true"
sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$M4]} "kill $SERVER_PID_M4 >/dev/null 2>&1; killall iperf 2>/dev/null || true"

cat "$TEMP_FILE_1" >> "$OUTPUT_FILE" 2>/dev/null
cat "$TEMP_FILE_2" >> "$OUTPUT_FILE" 2>/dev/null

sleep 5

# ============================================================================
# PHASE 3: AGGREGATE THROUGHPUT TEST (BIDIRECTIONAL)
# ============================================================================
{
  echo ""
  echo "---"
  echo ""
  echo "## Phase 3: Aggregate Throughput Test (Bidirectional)"
  echo ""
  echo "Testing 4 simultaneous bidirectional flows to measure maximum aggregate capacity."
  echo "* Flow 1: nf$M1 ↔ nf$M2 (${NODE_ADDR[$M1]} ↔ ${NODE_ADDR[$M2]})"
  echo "* Flow 2: nf$M3 ↔ nf$M4 (${NODE_ADDR[$M3]} ↔ ${NODE_ADDR[$M4]})"
  echo ""
} >> "$OUTPUT_FILE"

echo "=== Phase 3: Aggregate Throughput Test (Bidirectional) ==="

TEMP_FILE_1="$TEMP_DIR/result_${M1}_to_${M2}_bidir.txt"
TEMP_FILE_2="$TEMP_DIR/result_${M3}_to_${M4}_bidir.txt"
TEMP_FILE_3="$TEMP_DIR/result_${M2}_to_${M1}_bidir.txt"
TEMP_FILE_4="$TEMP_DIR/result_${M4}_to_${M3}_bidir.txt"

echo "Cleaning up any leftover iperf processes..."
for node in "${NODES[@]}"; do
    sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$node]} \
        "killall iperf 2>/dev/null || true" &
done
wait
sleep 2

echo "Starting iperf servers on all nodes..."
SERVER_PID_M1=$(sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$M1]} \
    "nohup iperf -s -u -p ${NODE_PORTS[$M1]} > /dev/null 2>&1 & echo \$!")
SERVER_PID_M2=$(sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$M2]} \
    "nohup iperf -s -u -p ${NODE_PORTS[$M2]} > /dev/null 2>&1 & echo \$!")
SERVER_PID_M3=$(sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$M3]} \
    "nohup iperf -s -u -p ${NODE_PORTS[$M3]} > /dev/null 2>&1 & echo \$!")
SERVER_PID_M4=$(sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$M4]} \
    "nohup iperf -s -u -p ${NODE_PORTS[$M4]} > /dev/null 2>&1 & echo \$!")
sleep 3

echo "Verifying iperf servers..."
for check_node in "${NODES[@]}"; do
    SRV_CHECK=$(sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$check_node]} \
        "ps aux | grep -c '[i]perf'")
    if [ "$SRV_CHECK" -ge 1 ]; then
        echo "  ✓ iperf server running on nf$check_node"
    else
        echo "  ✗ iperf server NOT running on nf$check_node — restarting..."
        sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$check_node]} \
            "nohup iperf -s -u -p ${NODE_PORTS[$check_node]} > /dev/null 2>&1 &"
        sleep 2
    fi
done

echo "Running 4 simultaneous bidirectional flows..."
run_iperf_client "$M2" "$M1" "$TEMP_FILE_1" "$AGG_BW_FILE" "${NODE_PORTS[$M2]}" &
PID1=$!
run_iperf_client "$M1" "$M2" "$TEMP_FILE_3" "$AGG_BW_FILE" "${NODE_PORTS[$M1]}" &
PID2=$!
run_iperf_client "$M4" "$M3" "$TEMP_FILE_2" "$AGG_BW_FILE" "${NODE_PORTS[$M4]}" &
PID3=$!
run_iperf_client "$M3" "$M4" "$TEMP_FILE_4" "$AGG_BW_FILE" "${NODE_PORTS[$M3]}" &
PID4=$!

wait $PID1 $PID2 $PID3 $PID4

for node in "${NODES[@]}"; do
    sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$node]} \
        "killall iperf 2>/dev/null || true" &
done
wait

cat "$TEMP_FILE_1" >> "$OUTPUT_FILE" 2>/dev/null
cat "$TEMP_FILE_2" >> "$OUTPUT_FILE" 2>/dev/null
cat "$TEMP_FILE_3" >> "$OUTPUT_FILE" 2>/dev/null
cat "$TEMP_FILE_4" >> "$OUTPUT_FILE" 2>/dev/null

sleep 5

# ============================================================================
# PHASE 4: INDIVIDUAL FLOW BASELINE TESTS (SEQUENTIAL)
# ============================================================================
{
  echo ""
  echo "---"
  echo ""
  echo "## Phase 4: Individual Flow Baseline Tests"
  echo ""
  echo "Testing each flow individually (sequentially) to establish baseline performance."
  echo ""
} >> "$OUTPUT_FILE"

echo "=== Phase 4: Individual Flow Baseline Tests ==="

for target_node in "${NODES[@]}"; do
    port=${NODE_PORTS[$target_node]}
    echo "Testing connections to server nf$target_node (${NODE_ADDR[$target_node]}:$port)..."

    sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$target_node]} \
        "killall iperf 2>/dev/null || true"
    sleep 1

    SERVER_PID=$(sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$target_node]} \
        "nohup iperf -s -u -p $port > /dev/null 2>&1 & echo \$!")
    sleep 2

    SRV_CHECK=$(sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$target_node]} \
        "ps aux | grep -c '[i]perf'")
    if [ "$SRV_CHECK" -ge 1 ]; then
        echo "  ✓ iperf server running on nf$target_node:$port"
    else
        echo "  ✗ iperf server NOT running on nf$target_node — restarting..."
        sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$target_node]} \
            "nohup iperf -s -u -p $port > /dev/null 2>&1 &"
        sleep 2
    fi

    client_nodes=()
    for node in "${NODES[@]}"; do
        [ "$node" != "$target_node" ] && client_nodes+=($node)
    done

    for client_node in "${client_nodes[@]}"; do
        TEMP_FILE="$TEMP_DIR/result_${client_node}_to_${target_node}_single.txt"
        run_iperf_client "$target_node" "$client_node" "$TEMP_FILE" "$BW_FILE" "$port"
        cat "$TEMP_FILE" >> "$OUTPUT_FILE" 2>/dev/null
        sleep 2
    done

    echo "Stopping iperf server on nf$target_node:$port"
    sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$target_node]} \
        "kill $SERVER_PID >/dev/null 2>&1; killall iperf 2>/dev/null || true"
    sleep 2
done

# ============================================================================
# CALCULATE STATISTICS
# ============================================================================

agg_total=0
agg_count=0
while read -r bw; do
    if [ -n "$bw" ] && [ "$bw" != "N/A" ]; then
        agg_total=$(echo "$agg_total + $bw" | bc)
        agg_count=$((agg_count + 1))
    fi
done < "$AGG_BW_FILE"

ind_total=0
ind_count=0
ind_peak=0
ind_min=999999
while read -r bw; do
    if [ -n "$bw" ] && [ "$bw" != "N/A" ]; then
        ind_total=$(echo "$ind_total + $bw" | bc)
        ind_count=$((ind_count + 1))
        is_higher=$(echo "$bw > $ind_peak" | bc)
        if [ "$is_higher" -eq 1 ]; then
            ind_peak=$bw
        fi
        is_lower=$(echo "$bw < $ind_min" | bc)
        if [ "$is_lower" -eq 1 ]; then
            ind_min=$bw
        fi
    fi
done < "$BW_FILE"
[ "$ind_min" = "999999" ] && ind_min=0

{
  echo ""
  echo "---"
  echo ""
  echo "## Summary Statistics"
  echo ""
  echo "### Phase 1: Latency & Cross-Port Connectivity"
  echo ""
  echo "* Bitfile type: **$BITFILE_TYPE**"
  echo "* Adjacent port pairs: $adjacent_ok OK, $adjacent_fail FAIL"
  echo "* Cross-port pairs:    $cross_ok OK, $cross_fail FAIL"
  echo "* Average RTT (adjacent): ${avg_adjacent_rtt} ms"
  echo "* Average RTT (cross-port): ${avg_cross_rtt} ms"
  echo ""
} >> "$OUTPUT_FILE"

echo ""
echo "============================================"
echo "  Final Summary"
echo "============================================"
echo ""
echo "Phase 1 - Connectivity: Adjacent=$adjacent_ok OK/$adjacent_fail FAIL | Cross-port=$cross_ok OK/$cross_fail FAIL"
echo "Phase 1 - Latency:      Adjacent avg=${avg_adjacent_rtt}ms | Cross-port avg=${avg_cross_rtt}ms"

if [ $agg_count -gt 0 ]; then
    agg_average=$(echo "scale=2; $agg_total / $agg_count" | bc)
    {
      echo "### Phases 2-3: Aggregate Throughput Tests"
      echo "* Total flows tested: $agg_count"
      echo "* Average per-flow bandwidth: $agg_average Mbits/sec"
      echo "* **Total aggregate bandwidth: $(echo "scale=2; $agg_total" | bc) Mbits/sec**"
      echo ""
    } >> "$OUTPUT_FILE"
    echo "Phase 2-3 - Aggregate: $(echo "scale=2; $agg_total" | bc) Mbits/sec total across $agg_count flows (avg $agg_average Mbits/sec per flow)"
fi

if [ $ind_count -gt 0 ]; then
    ind_average=$(echo "scale=2; $ind_total / $ind_count" | bc)
    {
      echo "### Phase 4: Individual Flow Baseline Tests"
      echo "* Total flows tested: $ind_count"
      echo "* **Peak individual flow bandwidth: $ind_peak Mbits/sec**"
      echo "* **Min individual flow bandwidth: $ind_min Mbits/sec**"
      echo "* **Average individual flow bandwidth: $ind_average Mbits/sec**"
      echo ""
    } >> "$OUTPUT_FILE"
    echo "Phase 4 - Individual:  peak=$ind_peak, min=$ind_min, avg=$ind_average Mbits/sec across $ind_count flows"
fi

# ============================================================================
# CLEANUP
# ============================================================================

if [ $RKD_ENABLE -eq 1 ]; then
    echo ""
    echo "Stopping RKD on nf$M0..."
    sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no netfpga@${NODE_SSH[$M0]} \
        "killall rkd 2>/dev/null || true"
    echo "RKD stopped."
fi

echo "Final cleanup: stopping all iperf processes..."
for node in "${NODES[@]}"; do
    sshpass -p "$PASSWORD" ssh -o StrictHostKeyChecking=no node$ND@${NODE_SSH[$node]} \
        "killall iperf 2>/dev/null || true" &
done
wait

rm -rf "$TEMP_DIR"
echo ""
echo "============================================"
echo "All tests completed!"
echo "Results saved in: $OUTPUT_FILE"
echo "============================================"