/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;


int isim_run(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    work_m_00000000000866782574_2073120511_init();
    unisims_ver_m_00000000002063979698_0906273847_init();
    unisims_ver_m_00000000002063979698_1090753697_init();
    unisims_ver_m_00000000002063979698_3624584475_init();
    unisims_ver_m_00000000002063979698_2936927629_init();
    unisims_ver_m_00000000002063979698_0828989486_init();
    unisims_ver_m_00000000002063979698_1181634744_init();
    unisims_ver_m_00000000002063979698_3748069634_init();
    unisims_ver_m_00000000002063979698_2824876436_init();
    work_m_00000000003490390565_2665867818_init();
    unisims_ver_m_00000000000084376409_3411452309_init();
    unisims_ver_m_00000000002033260902_0484350389_init();
    unisims_ver_m_00000000001933396858_1058825862_init();
    unisims_ver_m_00000000003966557861_2771340377_init();
    unisims_ver_m_00000000003419914672_0302322055_init();
    unisims_ver_m_00000000000179858743_3125220529_init();
    work_m_00000000001704989061_0549885969_init();
    unisims_ver_m_00000000003257999491_1759035934_init();
    work_m_00000000002917818316_0056698376_init();


    xsi_register_tops("work_m_00000000002917818316_0056698376");
    xsi_register_tops("work_m_00000000000866782574_2073120511");


    return xsi_run_simulation(argc, argv);

}
