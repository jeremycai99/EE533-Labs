#!/bin/env python

from subprocess import call

call('./ip_interface.pl')
